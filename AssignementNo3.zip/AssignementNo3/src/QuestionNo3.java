
public class QuestionNo3 {
	
	
	static void revers(int arr[]) {
		Que2Stack stack=new Que2Stack(arr.length);
		stack 
		
		
		
	}
public static void main(String[] args) {
	 //Create an array of integers. Reverse the array using stacks
	
	int arr[]= {80,70,60,50,40,30,20,10};
	revers(arr);
	
	
}
}
