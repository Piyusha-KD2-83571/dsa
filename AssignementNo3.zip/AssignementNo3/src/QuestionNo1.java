
public class QuestionNo1 {
	public static void main(String[] args) {
    //1. Write a program to implement descending stack. (Initialize top = SIZE
	stack st=new stack(5);
	st.push(10);
	st.push(20);
	st.push(30);
	st.peek();
//	st.push(20);
//	st.push(30);
//	st.push(20);
//	st.push(30); 
	//st.dispaly();
	}
}
