package Q2;

public class Q2main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		deque d=new deque();
		
		d.pushf(10);
		d.pushr(15);
		d.pushf(25);
		System.out.println("The data is "+d.peek());

	}

}
