
public enum Category {
	Exit,Search_By_EmployeeID,
	Search_by_Employee_Name,
	Search_by_Employee_Salary
}
